# Smart Traffic + AI Prediction

Flutter demo app for K Kavya (248T1A4429), Dhanekula Institute of Engineering and Technology.

## Run
1. Install Flutter SDK and Android Studio (or VS Code with Flutter extension).
2. In a terminal, go to this folder.
3. Run `flutter pub get`
4. Run `flutter run`

This project currently runs entirely with illustrative demo data and no API key. The live-map screen is a schematic map, not GPS navigation. The prediction screen uses transparent demo values/rules; it is not a trained AI model and does not represent live traffic. Connect a verified traffic provider and a validated ML model before describing predictions as live.

## Suggested next integrations
- Replace `demoSegments` with a repository backed by a traffic API.
- Implement a `TrafficPredictionService` using a trained model or remote inference endpoint.
- Configure Google Maps and Firebase only when credentials are available.
